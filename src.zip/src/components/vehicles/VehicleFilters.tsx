import React from 'react';
import { Search } from 'lucide-react';

interface VehicleFiltersProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  statusFilter: string;
  onStatusFilterChange: (status: string) => void;
  makeFilter: string;
  onMakeFilterChange: (make: string) => void;
  makes: string[];
  showSold: boolean;
  onShowSoldChange: (show: boolean) => void;
  showDueSoon: boolean;
  onShowDueSoonChange: (show: boolean) => void;
}

const VehicleFilters: React.FC<VehicleFiltersProps> = ({
  searchQuery,
  onSearchChange,
  statusFilter,
  onStatusFilterChange,
  makeFilter,
  onMakeFilterChange,
  makes,
  showSold,
  onShowSoldChange,
  showDueSoon,
  onShowDueSoonChange,
}) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
      {/* Search */}
      <div className="relative col-span-1 sm:col-span-2 lg:col-span-2">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Search className="h-5 w-5 text-gray-400" />
        </div>
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder="Search vehicles..."
          className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
        />
      </div>

      {/* Status */}
      <select
        value={statusFilter}
        onChange={(e) => onStatusFilterChange(e.target.value)}
        className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm rounded-md"
      >
        <option value="all">All Status</option>
        <option value="available">Available</option>
        <option value="hired">Hired</option>
        <option value="scheduled-rental">Scheduled for Hire</option>
        <option value="maintenance">Maintenance</option>
      </select>

      {/* Make */}
      <select
        value={makeFilter}
        onChange={(e) => onMakeFilterChange(e.target.value)}
        className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm rounded-md"
      >
        <option value="all">All Makes</option>
        {makes.map((make) => (
          <option key={make} value={make}>{make}</option>
        ))}
      </select>

      {/* Toggles */}
      <div className="flex items-center justify-between gap-3 sm:col-span-2 lg:col-span-1">
        <label className="flex items-center space-x-2">
          <input
            type="checkbox"
            checked={showSold}
            onChange={(e) => onShowSoldChange(e.target.checked)}
            className="rounded border-gray-300 text-primary focus:ring-primary"
          />
          <span className="text-sm text-gray-700">Show Sold</span>
        </label>

        <label className="flex items-center space-x-2">
          <input
            type="checkbox"
            checked={showDueSoon}
            onChange={(e) => onShowDueSoonChange(e.target.checked)}
            className="rounded border-gray-300 text-primary focus:ring-primary"
          />
          <span className="text-sm text-gray-700">Due Soon</span>
        </label>
      </div>
    </div>
  );
};

export default VehicleFilters;
