import React from 'react';
import { IncomeExpenseEntry, ProfitShare } from '../../types/incomeExpense';
import { useFormattedDisplay } from '../../hooks/useFormattedDisplay';

interface Props {
  entries?: IncomeExpenseEntry[];
  shares?: ProfitShare[];
  startDate?: string;
  endDate?: string;
}

export default function IncomeExpenseSummary({
  entries = [],
  shares = [],
  startDate,
  endDate
}: Props) {
  const { formatCurrency } = useFormattedDisplay();

  const totalIncome = entries
    .filter(e => e.type === 'income')
    .reduce((sum, e) => sum + (e.total ?? (e as any).totalCost ?? 0), 0);


    const totalExpense = entries
    .filter(e => e.type === 'expense')
    .reduce((sum, e) => sum + (e.total ?? (e as any).totalCost ?? 0), 0);
  

  const totalShared = shares
    .reduce((sum, sp) => sum + sp.totalSplitAmount, 0);

  const balance = totalIncome - totalExpense - totalShared;

  const breakdown = shares.reduce<Record<string, number>>((acc, sp) => {
    sp.recipients.forEach(rec => {
      acc[rec.name] = (acc[rec.name] || 0) + rec.amount;
    });
    return acc;
  }, {});

  const cards = [
    { label: 'Income', amount: totalIncome, color: 'text-gray-900' },
    { label: 'Expense', amount: totalExpense, color: 'text-red-600' },
    { label: 'Shared', amount: totalShared, color: 'text-blue-600', isShared: true },
    { label: 'Balance', amount: balance, color: 'text-green-600' }
  ] as const;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {cards.map(card => (
        <div key={card.label} className="bg-white rounded-lg shadow-sm p-6">
          <h3 className="text-sm font-medium text-gray-500">
            {card.label.toUpperCase()}
          </h3>

          {card.isShared && (
            <div className="mt-2 space-y-1 text-sm text-gray-700">
              {startDate && endDate && (
                <p className="italic text-xs text-gray-500">
                  {startDate} → {endDate}
                </p>
              )}
              {Object.entries(breakdown).map(([name, amt]) => {
                const pct = totalShared > 0 ? Math.round((amt / totalShared) * 100) : 0;
                return (
                  <p key={name}>
                    <span className="font-medium">{name}</span>{' '}
                    ({pct}%) = <span className="font-semibold">{formatCurrency(amt)}</span>
                  </p>
                );
              })}
            </div>
          )}

          <p className={`mt-2 text-3xl font-semibold ${card.color}`}>
            {formatCurrency(card.amount)}
          </p>
        </div>
      ))}
    </div>
  );
}
