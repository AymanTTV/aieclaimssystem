import React, { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { format } from 'date-fns';
import { useCustomers } from '../hooks/useCustomers';
import { useVehicles } from '../hooks/useVehicles';
import { useRentals } from '../hooks/useRentals';
import { useInvoices } from '../hooks/useInvoices';
import { useMaintenanceLogs } from '../hooks/useMaintenanceLogs';
import { useClaims } from '../hooks/useClaims';
import { useServiceCenters } from '../hooks/useServiceCenters';
import { fetchLegalHandlers } from '../utils/legalHandlers';
import { emailTemplates, EmailTemplate } from '../constants/EmailTemplates';
import { generateEmailFromTemplate, sendEmail } from '../utils/emailService';
import { db } from '../lib/firebase';
import { addDoc, collection, Timestamp, query, orderBy } from 'firebase/firestore';
import SearchableSelect from '../components/ui/SearchableSelect';
import { useCollection } from 'react-firebase-hooks/firestore';

const EmailHistory = () => {
  const [typeFilter, setTypeFilter] = useState('');
  const [logsSnapshot] = useCollection(
    query(
      collection(db, 'emailLogs'),
      orderBy('sentAt', 'desc')
    )
  );

  const logs = logsSnapshot?.docs.map(doc => ({ id: doc.id, ...doc.data() })) || [];

  const filteredLogs = logs.filter(log =>
    !typeFilter || log.emailType === typeFilter
  );

  return (
    <div className="mt-10">
      <h2 className="text-lg font-semibold mb-4">📬 Email Send History</h2>
      <div className="flex gap-4 items-center mb-4">
        <label>Email Type</label>
        <select
          value={typeFilter}
          onChange={(e) => setTypeFilter(e.target.value)}
          className="border p-2"
        >
          <option value="">All</option>
          <option value="custom">Custom</option>
          <option value="rental">Rental</option>
          <option value="maintenance">Maintenance</option>
          <option value="invoice">Invoice</option>
          <option value="claim">Claim</option>
        </select>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full border text-sm">
          <thead>
            <tr className="bg-gray-100">
              <th className="border px-2 py-1 text-left">Date</th>
              <th className="border px-2 py-1 text-left">Type</th>
              <th className="border px-2 py-1 text-left">Recipient</th>
              <th className="border px-2 py-1 text-left">Subject</th>
              <th className="border px-2 py-1 text-left">Sent By</th>
            </tr>
          </thead>
          <tbody>
            {filteredLogs.map(log => (
              <tr key={log.id}>
                <td className="border px-2 py-1">{log.sentAt?.toDate().toLocaleString()}</td>
                <td className="border px-2 py-1 capitalize">{log.emailType}</td>
                <td className="border px-2 py-1">{log.recipientEmail}</td>
                <td className="border px-2 py-1">{log.subject}</td>
                <td className="border px-2 py-1">{log.sentBy || 'System'}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {!filteredLogs.length && <p className="text-sm text-gray-500 mt-2">No emails sent yet.</p>}
      </div>
    </div>
  );
};

const BulkEmail = () => {
  const { customers } = useCustomers();
  const { vehicles } = useVehicles();
  const { rentals } = useRentals();
  const { invoices } = useInvoices();
  const { maintenanceLogs } = useMaintenanceLogs();
  const { claims } = useClaims();
  const { serviceCenters } = useServiceCenters();

  const [emailType, setEmailType] = useState('custom');
  const [templateId, setTemplateId] = useState('');
  const [template, setTemplate] = useState<EmailTemplate | null>(null);
  const [recipient, setRecipient] = useState<any>(null);
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);
  const [attachments, setAttachments] = useState<File[]>([]);

  const availableTemplates = Object.values(emailTemplates[emailType] || {});

  useEffect(() => {
    if (templateId && emailTemplates[emailType]) {
      setTemplate(emailTemplates[emailType][templateId]);
    } else {
      setTemplate(null);
    }
  }, [templateId, emailType]);

  useEffect(() => {
    if (!template || !recipient) return;

    const context: any = {
      customer: recipient,
      vehicle: null,
      rental: null,
      maintenance: null,
      invoice: null,
      claim: null,
    };

    if (template.requiredData.includes('vehicle')) {
      const assigned = rentals.find(
        r => r.customerId === recipient.id && r.status === 'active'
      );
      if (assigned) {
        context.rental = assigned;
        context.vehicle = vehicles.find(v => v.id === assigned.vehicleId);
      }
    }

    if (template.requiredData.includes('maintenance')) {
      const vehicleId = context.vehicle?.id;
      context.maintenance = maintenanceLogs.find(m => m.vehicleId === vehicleId);
    }

    if (template.requiredData.includes('invoice')) {
      context.invoice = invoices.find(inv => inv.customerId === recipient.id);
    }

    if (template.requiredData.includes('claim')) {
      context.claim = claims.find(c => c.customerId === recipient.id);
    }

    const { subject, message } = generateEmailFromTemplate(template, context);
    setSubject(subject);
    setMessage(message);
  }, [template, recipient]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      setAttachments(Array.from(files));
    }
  };

  const handleSend = async () => {
    if (!recipient || !subject || !message) {
      toast.error('Missing recipient or message');
      return;
    }

    setSending(true);
    try {
      await sendEmail({
        to_email: recipient.email,
        to_name: recipient.name || 'Recipient',
        subject,
        message,
        // attachments will be integrated into the sending logic as needed
      });

      await addDoc(collection(db, 'emailLogs'), {
        emailType,
        templateId,
        recipientId: recipient.id,
        recipientEmail: recipient.email,
        subject,
        message,
        sentAt: Timestamp.now(),
        sentBy: 'system',
      });

      toast.success('Email sent!');
      setRecipient(null);
      setTemplateId('');
      setMessage('');
      setAttachments([]);
    } catch (error) {
      toast.error('Failed to send email.');
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="p-6">
      <h1 className="text-xl font-bold mb-4">Bulk Email</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
        <div>
          <label>Email Type</label>
          <select value={emailType} onChange={e => setEmailType(e.target.value)} className="w-full border p-2">
            <option value="custom">Custom</option>
            <option value="rental">Rental</option>
            <option value="maintenance">Maintenance</option>
            <option value="invoice">Invoice</option>
            <option value="claim">Claim</option>
          </select>
        </div>

        <div>
          <label>Email Template</label>
          <select value={templateId} onChange={e => setTemplateId(e.target.value)} className="w-full border p-2">
            <option value="">Select Template</option>
            {availableTemplates.map(t => (
              <option key={t.id} value={t.id}>{t.label}</option>
            ))}
          </select>
        </div>

        <div>
          <label>Recipient</label>
          <SearchableSelect
            options={customers}
            getOptionLabel={c => c.name}
            getOptionValue={c => c.id}
            value={recipient}
            onChange={setRecipient}
            placeholder="Search recipient..."
          />
        </div>
      </div>

      <div className="mb-4">
        <label>Subject</label>
        <input
          className="w-full border p-2"
          value={subject}
          onChange={e => setSubject(e.target.value)}
        />
      </div>

      <div className="mb-4">
        <label>Message</label>
        <textarea
          className="w-full border p-2 h-60"
          value={message}
          onChange={e => setMessage(e.target.value)}
        />
      </div>

      <div className="mb-4">
        <label>Attachments</label>
        <input
          type="file"
          multiple
          onChange={handleFileChange}
          className="block border p-2 w-full"
        />
      </div>

      <button
        className="bg-blue-600 text-white px-4 py-2 rounded"
        onClick={handleSend}
        disabled={sending}
      >
        {sending ? 'Sending...' : 'Send Email'}
      </button>

      <EmailHistory />
    </div>
  );
};

export default BulkEmail;
