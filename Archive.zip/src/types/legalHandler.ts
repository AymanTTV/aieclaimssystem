// src/types/legalHandler.ts

export interface LegalHandler {
    id: string;
    name: string;
    email: string;
    address: string;
    phone: string;
  }