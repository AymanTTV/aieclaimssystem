import { EmailTemplate } from '../constants/EmailTemplates';

type TemplateContext = {
  customer?: any;
  vehicle?: any;
  rental?: any;
  maintenance?: any;
  invoice?: any;
  claim?: any;
  legalHandler?: any;
  serviceCenter?: any;
};

const formatDate = (date: any): string => {
  try {
    return new Date(date).toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    });
  } catch {
    return 'N/A';
  }
};

const formatDateTime = (date: any): string => {
  try {
    return new Date(date).toLocaleString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return 'N/A';
  }
};

export const generateEmailFromTemplate = (
  template: EmailTemplate,
  context: TemplateContext
): { subject: string; message: string } => {
  let { subject, body } = template;

  const replace = (text: string) =>
    text
      .replace(/\[Customer Name\]/g, context.customer?.name || 'N/A')
      .replace(/\[Driver's Name\]/g, context.customer?.name || 'N/A')
      .replace(/\[Driver’s Full Name\]/g, context.customer?.name || 'N/A')
      .replace(/\[Vehicle Reg No\]/g, context.vehicle?.registrationNumber || 'N/A')
      .replace(/\[Vehicle Registration Number\]/g, context.vehicle?.registrationNumber || 'N/A')
      .replace(/\[Vehicle Make\]/g, context.vehicle?.make || 'N/A')
      .replace(/\[Vehicle Model\]/g, context.vehicle?.model || 'N/A')
      .replace(/\[Insert Today’s Date\]/g, formatDate(new Date()))
      .replace(/\[Service Type\]/g, context.maintenance?.serviceType || 'N/A')
      .replace(/\[Date & Time of Appointment\]/g, formatDateTime(context.maintenance?.appointmentDate))
      .replace(/\[Service Centre Name or Address\]/g, context.maintenance?.location || 'N/A')
      .replace(/\[Start Date\]/g, formatDate(context.rental?.startDate))
      .replace(/\[End Date\]/g, formatDate(context.rental?.endDate))
      .replace(/\[Rental Type\]/g, context.rental?.type || 'N/A')
      .replace(/\[Total Amount\]/g, context.rental?.cost?.toFixed(2) || '0.00')
      .replace(/\[Amount Paid\]/g, context.rental?.paidAmount?.toFixed(2) || '0.00')
      .replace(/\[Outstanding Balance\]/g, context.rental?.remainingAmount?.toFixed(2) || '0.00')
      .replace(/\[Original Due Date\]/g, formatDate(context.rental?.dueDate))
      .replace(/\[Invoice Number\]/g, context.invoice?.invoiceNumber || 'N/A')
      .replace(/\[Invoice Date\]/g, formatDate(context.invoice?.invoiceDate))
      .replace(/\[Due Date\]/g, formatDate(context.invoice?.dueDate))
      .replace(/\[Amount\]/g, context.invoice?.amount?.toFixed(2) || '0.00')
      .replace(/\[Description\]/g, context.invoice?.description || 'N/A')
      .replace(/\[Repair Date or Time Frame\]/g, formatDate(context.maintenance?.date || context.maintenance?.appointmentDate))
      .replace(/\[Description of the repair service\]/g, context.maintenance?.serviceType || 'N/A')
      .replace(/\[Insert Registration Number\]/g, context.vehicle?.registrationNumber || 'N/A')
      .replace(/\[Insert Make and Model\]/g, `${context.vehicle?.make || ''} ${context.vehicle?.model || ''}`)
      .replace(/\[Insert Year of First Registration\]/g, context.vehicle?.year || 'N/A')
      .replace(/\[Recipient's Name\]/g, context.legalHandler?.name || context.serviceCenter?.name || 'N/A')
      .replace(/\[Client Name\]/g, context.claim?.customerName || context.customer?.name || 'N/A')
      .replace(/\[Client Registration\]/g, context.claim?.customerReg || context.vehicle?.registrationNumber || 'N/A')
      .replace(/\[Third Party Registration\]/g, context.claim?.thirdPartyReg || 'N/A')
      .replace(/\[Date\]/g, formatDate(context.claim?.incidentDate))
      .replace(/\[Time\]/g, context.claim?.incidentTime || 'N/A')
      .replace(/\[Location\]/g, context.claim?.incidentLocation || 'N/A')
      .replace(/\[Incident Description\]/g, context.claim?.incidentDescription || 'N/A')
      .replace(/\[Insert Case\/File Reference Number\]/g, context.claim?.referenceNumber || 'N/A');

  return {
    subject: replace(subject),
    message: replace(body),
  };
};
