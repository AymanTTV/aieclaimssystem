// src/constants/EmailTemplates.ts

export type EmailTemplate = {
  id: string;
  label: string;
  subject: string;
  body: string;
  requiredData: string[]; // For validation / auto-fill logic
};

type EmailTemplateGroup = {
  [templateId: string]: EmailTemplate;
};

type EmailTemplatesByType = {
  [emailType: string]: EmailTemplateGroup;
};

export const emailTemplates: EmailTemplatesByType = {
  custom: {
    mileage_request: {
      id: 'mileage_request',
      label: 'Mileage Request',
      subject: 'Request for Current Vehicle Mileage – [Vehicle Registration Number]',
      body: `Dear [Driver's Name],

I hope you are well. Please could you provide the current mileage reading for the following vehicle at your earliest convenience:

🔹 Vehicle Registration Number: [Vehicle Reg No]  
🔹 Your Name: [Driver’s Full Name]  
🔹 Date of Reading: [Insert Today’s Date]  

This is required for our internal records and maintenance scheduling. A clear photo of the dashboard showing the mileage would be appreciated if possible.

Thank you for your cooperation.

Best regards,  
AIE Skyline Limited  
📍 United House, 39-41 North Road, London, N7 9DP  
📞 020 8050 5337 | 📱 +44 7999 558801  
✉️ admin@aieskyline.co.uk  
🌐 www.aieskyline.co.uk`,
      requiredData: ['vehicle', 'customer']
    },
    service_booking: {
      id: 'service_booking',
      label: 'Your Vehicle is Booked for Service',
      subject: 'Vehicle Service Booking Confirmation – [Vehicle Registration Number]',
      body: `Dear [Driver's Name],

I hope you're well. Please note that your vehicle has been booked in for service as per the details below:

🔹 Vehicle Registration Number: [Vehicle Reg No]  
🔹 Service Type: [Service Type]  
🔹 Date & Time: [Date & Time of Appointment]  
🔹 Location: [Service Centre Name or Address]  

Please ensure the vehicle is available at the scheduled time and location. Let us know immediately if there are any issues with attending the appointment.

Thank you for your cooperation.

Best regards,  
AIE Skyline Limited  
📍 United House, 39-41 North Road, London, N7 9DP  
📞 020 8050 5337 | 📱 +44 7999 558801  
✉️ admin@aieskyline.co.uk  
🌐 www.aieskyline.co.uk`,
      requiredData: ['vehicle', 'maintenance', 'customer']
    }
  },

  rental: {
    welcome: {
      id: 'welcome',
      label: 'Rental Welcome',
      subject: 'Welcome to AIE Skyline!',
      body: `Thank you for choosing us for your vehicle rental needs.

We’re delighted to have you on board and are committed to providing a smooth, professional, and hassle-free experience.

...

🌐 www.aieskyline.co.uk`,
      requiredData: ['customer']
    },
    outstanding: {
      id: 'outstanding',
      label: 'Rental Outstanding',
      subject: 'Outstanding Rental Payment – Immediate Attention Required',
      body: `Dear [Customer Name],

This is a reminder that an outstanding payment remains on your recent vehicle rental...

Rental Period: [Start Date] to [End Date]  
Rental Type: [Rental Type]  
...

🌐 www.aieskyline.co.uk`,
      requiredData: ['rental', 'vehicle', 'customer']
    },
    completed: {
      id: 'completed',
      label: 'Rental Completed',
      subject: 'Thank You – Rental Successfully Completed',
      body: `Dear [Customer Name],

Thank you for choosing AIE Skyline. Your rental has now been successfully completed.

Rental Summary:  
Registration Number: [Vehicle Reg No]  
Rental Period: [Start Date] to [End Date]

...

🌐 www.aieskyline.co.uk`,
      requiredData: ['rental', 'vehicle', 'customer']
    },
    overdue: {
      id: 'overdue',
      label: 'Rental Overdue',
      subject: 'Urgent: Overdue Rental Payment – Immediate Action Required',
      body: `Dear [Customer Name],

This is a formal notice that your rental payment is now overdue...

Due Date: [Original Due Date]  
Outstanding Balance: £[Outstanding Balance]

...

🌐 www.aieskyline.co.uk`,
      requiredData: ['rental', 'vehicle', 'customer']
    }
  },

  maintenance: {
    part_request: {
      id: 'part_request',
      label: 'Request Part Price and Availability',
      subject: 'Request for LEVC Part Pricing and Availability',
      body: `Dear LEVC Parts Department,

Please provide pricing and availability for:

Registration Number: [Insert Registration Number]  
Make and Model: [Insert Make and Model]  
Year of First Registration: [Insert Year of First Registration]

...

AIE Skyline Limited`,
      requiredData: ['vehicle']
    },
    service_booking: {
      id: 'service_booking',
      label: 'Vehicle Service Booking',
      subject: 'Maintenance Service Request for Tyre Replacement – Vehicle Registration: [Vehicle Reg No]',
      body: `Dear LEVC Service Team,

Kindly arrange a maintenance service for:

🔹 Vehicle Registration Number: [Vehicle Reg No]  
🔹 Service Type: [Service Type]  
🔹 Preferred Date & Time: [Date & Time of Appointment]  
🔹 Location: [Service Centre Name or Address]

...

admin@aieskyline.co.uk`,
      requiredData: ['vehicle', 'maintenance']
    },
    invoice_request: {
      id: 'invoice_request',
      label: 'Vehicle Invoice Request',
      subject: 'Request for Vehicle Repair Invoice – [Invoice/Repair Reference Number]',
      body: `Dear LEVC Service Team,

I kindly request the invoice for the following:

🔹 Vehicle Registration Number: [Vehicle Reg No]  
🔹 Repair Service Date: [Repair Date or Time Frame]  
🔹 Service Type: [Description of the repair service]

...

AIE Skyline Limited`,
      requiredData: ['vehicle', 'maintenance']
    }
  },

  invoice: {
    pay_reminder: {
      id: 'pay_reminder',
      label: 'Please Pay Outstanding Invoice',
      subject: 'Outstanding Invoice Reminder – Immediate Attention Required',
      body: `Dear [Customer Name],

🔹 Invoice Number: [Invoice Number]  
🔹 Invoice Date: [Invoice Date]  
🔹 Amount Due: £[Amount]  
🔹 Due Date: [Due Date]

...

AIE Skyline Admin Team`,
      requiredData: ['invoice', 'customer']
    },
    new_invoice: {
      id: 'new_invoice',
      label: 'Invoice New',
      subject: 'New Invoice Issued – [Invoice Number]',
      body: `Dear [Customer Name],

🔹 Invoice Number: [Invoice Number]  
🔹 Invoice Date: [Invoice Date]  
🔹 Amount Due: £[Amount]  
🔹 Due Date: [Due Date]  
🔹 Description: [Brief description of service]

...

AIE Skyline Admin Team`,
      requiredData: ['invoice', 'customer']
    }
  },

  claim: {
    started: {
      id: 'started',
      label: 'Claim Started Submission',
      subject: 'New Case Submission – Documents and Details Enclosed',
      body: `Hi [Recipient's Name],

New case submitted with documents.

Client Name: [Client Name]  
Client Registration: [Client Registration]  
...

AIE Claims Ltd`,
      requiredData: ['claim']
    },
    update_request: {
      id: 'update_request',
      label: 'Claim Update Needed',
      subject: 'Request for Case Update – [Insert Case/File Reference Number]',
      body: `Dear [Recipient's Name],

Requesting an update on the following case:

Case/File Reference Number: [Insert Case/File Reference Number]  
Client Name: [Insert Client Name]  
...

AIE Claims Ltd`,
      requiredData: ['claim']
    }
  }
};
